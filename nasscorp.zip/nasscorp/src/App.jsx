import React from 'react'
import './App.css'

const App = () => {

  return (
   <main>
 <div className="App">

<header className="header">
  <div className="container">
    <nav className="navbar">
      <a href="#" className="logo">Nasscorp</a>
      <ul className="nav-links">
        <li><a href="#">Home</a></li>
        <li><a href="#">Product</a></li>
        <li><a href="#">Pricing</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <div className="nav-icons">
        <a href="#"><img src="/images/search.svg" alt="Search" className="icon-img" /></a>
        <a href="#"><img src="/images/icn shopping-cart .icn-xs.svg" alt="Cart" className="icon-img" /></a>
      </div>
    </nav>
  </div>
</header>

<section className="fardin-section">
  <div className="fardin-bg">
    <div className="overlay"></div>
    <div className="container fardin-content">
      <div className="fardin-text">
        <h1>Experts are here to solve your business problem.</h1>
        <p>We know how large objects will act, but things on a small scale just do not act that way.</p>
        <div className="fardin-buttons">
          <a href="#" className="btn btn-primary">Get Quote Now</a>
          <a href="#" className="btn btn-secondary">Learn More</a>
        </div>
      </div>
    </div>
  </div>
</section>

<section className="stats-section">
  <div className="container">
    <div className="stats-grid">
      <div className="stat-item">
        <img src="/images/man.svg" alt="Happy Customers" className="stat-icon-img" />
        <h3>1.5K</h3>
        <p>HAPPY CUSTOMERS</p>
      </div>
      <div className="stat-item">
        <img src="/images/Vector.svg" alt="Cases Done" className="stat-icon-img" />
        <h3>3K</h3>
        <p>CASES DONE</p>
      </div>
      <div className="stat-item">
        <img src="/images/carbon_notebook.svg" alt="Awards" className="stat-icon-img" />
        <h3>45</h3>
        <p>AWARD WINNING</p>
      </div>
      <div className="stat-item">
        <img src="/images/hunt.svg" alt="Countries" className="stat-icon-img" />
        <h3>12+</h3>
        <p>COUNTRIES WORLDWIDE</p>
      </div>
    </div>
  </div>
</section>

<section className="services-section">
  <div className="container">
    <div className="services-grid">

      <div className="service-card">
        <img src="/images/bussness.svg" alt="Business Growing" className="service-icon-img" />
        <h4>Business Growing</h4>
        <p>the quick fox jumps over the lazy dog</p>
        <a href="#" className="read-more">More</a>
      </div>

      <div className="service-card">
        <img src="/images/dijital.svg" alt="Digital Marketing" className="service-icon-img" />
        <h4>Digital Marketing</h4>
        <p>the quick fox jumps over the lazy dog</p>
        <a href="#" className="read-more">More</a>
      </div>

      <div className="service-card">
        <img src="/images/national.svg" alt="National" className="service-icon-img" />
        <h4>National top 50 firms</h4>
        <p>the quick fox jumps over the lazy dog</p>
        <a href="#" className="read-more">More</a>
      </div>

      <div className="service-card featured-service">
        <img src="/images/dijital marketing.svg" alt="Digital Marketing" className="service-icon-img" />
        <h4>Digital Marketing</h4>
        <p>the quick fox jumps over the lazy dog</p>
        <a href="#" className="read-more featured-read-more">More</a>
      </div>

    </div>
  </div>
</section>

{/* --- The rest of your sections are same pattern --- */}
{/* Want me to convert the remaining parts too? */}

</div>
   </main>
  );
}

export default App;
